import *as React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import PagerView from 'react-native-pager-view';

import First from './First/First';
import Second from './Second/Second';
import Third from './Third/Third';
import Un from './Bienvenue/Un';
import Fourth from './Fourth/Fourth';

const Home= () => {
  const pagerRef = React.useRef(null);

  const handlePageChange = (pageNumber) => {
    pagerRef.current.setPage(pageNumber);
  };

  return (
    <View style={styles.container}>
      <PagerView style={styles.pagerView} ref={pagerRef}>
        <View key="1">
          <Un onPageChange={handlePageChange} />
        </View>
        <View key="2">
          <First onPageChange={handlePageChange} />
        </View>
        <View key="3">
          <Second onPageChange={handlePageChange} />
        </View>
        <View key="4">
          <Third onPageChange={handlePageChange} />
        </View>
         <View key="5">
          <Fourth onPageChange={handlePageChange} />
        </View>
      </PagerView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  pagerView: {
    flex: 1,
  },
});

export default Home;
