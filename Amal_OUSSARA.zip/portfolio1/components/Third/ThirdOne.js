import React from 'react';
import { StyleSheet, View, Text, Image } from 'react-native';

export default function ThirdOne() {
  return (
    <View style={styles.container}>
      <View style={styles.logoContainer}>
        <Image source={require('./assets/EventsLocation.png')} style={styles.logo} />
        <Text style={styles.logoText}>EventsLocation</Text>
        <Image source={require('./assets/EventsLocation.png')} style={styles.logo} />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#fff',
  },
  logoContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#FF1493',
    paddingVertical: 20,
    paddingHorizontal: 30,
    borderRadius: 10,
    
  },
  logoText: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#fff',
    marginRight: 20,
  },
  logo: {
    width: 50,
    height: 50,
  },
});
