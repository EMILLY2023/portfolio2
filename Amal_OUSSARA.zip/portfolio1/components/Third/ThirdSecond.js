import React, { useState, useEffect } from 'react';
import { View, Text, FlatList, StyleSheet, ScrollView, SafeAreaView, Button} from 'react-native';

const ThirdSecond = () => {
  const [comments, setComments] = useState([]);
  const [page, setPage] = useState(1);

  useEffect(() => {
    fetch(`https://jsonplaceholder.typicode.com/comments?_page=${page}&_limit=10`)
      .then(response => response.json())
      .then(data => setComments(data))
      .catch(error => console.error(error));
  }, [page]);

  const handlePrevPage = () => {
    if (page > 1) {
      setPage(prevPage => prevPage - 1);
    }
  };

  const handleNextPage = () => {
    setPage(prevPage => prevPage + 1);
  };

  const renderItem = ({ item }) => (
    <View style={styles.commentCard}>
      <Text style={styles.textEmail}>{item.email}</Text>
      <Text style={styles.textName}>{item.name}</Text>
      <Text style={styles.textContent}>{item.body}</Text>
    </View>
  );

  return (
    <SafeAreaView style={styles.container}>
     <Text style={styles.commentTitle}>Liste des commentaires :</Text>
      <ScrollView>
        <FlatList
          data={comments}
          renderItem={renderItem}
          keyExtractor={item => item.id.toString()}
          ListFooterComponent={
            <View style={styles.paginationButtons}>
              <Button title="Prev" onPress={handlePrevPage} />
              <Button title="Next" onPress={handleNextPage} />
            </View>
          }
        />
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f9c2ff',
  },
  commentCard: {
    padding: 20,
    borderBottomColor: '#ccc',
    borderBottomWidth: 1,
  },
  textEmail: {
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 5,
  },
  textName: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#666',
    marginBottom: 5,
  },
  textContent: {
    fontSize: 14,
    color: '#666',
  },
  paginationButtons: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    paddingVertical: 20,
  },
   commentTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 10,
    
  },
});

export default ThirdSecond;

