import React from 'react';
import MapView, {Marker} from 'react-native-maps';
import { StyleSheet, View } from 'react-native';

export default function Map() {
  return (
    <View style={styles.containerMap}>
      <MapView initialRegion={{
    latitude: 48.5058,
    longitude: 2.3718,
    latitudeDelta: 48.849648,
    longitudeDelta: 2.621903,
  }} style={styles.map} >
        <Marker
          coordinate={{latitude: 48.84965, longitude: 2.621903}}
          title="EventsLocation"
          description="Des looks pour chaque occasion"
        />
      </MapView>
    </View>
  );
}

const styles = StyleSheet.create({
  containerMap: {
    flex: 1,
    backgroundColor: '#FF1493',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 30,
    width: '100%',
  },
  map: {
    width: '100%',
    height: '100%',
  },
});