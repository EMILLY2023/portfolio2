import * as React from 'react';
import { Text, ImageBackground, StyleSheet } from 'react-native';

export default function Fourth() {
  return (
    <ImageBackground source={require('./assets/background.png')} style={{width: '100%', height: '100%'}}>
      <Text style={styles.content}>Fin</Text>
      
    </ImageBackground>
  );
}

const styles = StyleSheet.create({
 
  content: {
    fontSize: 40,
    fontWeight: 'bold',
    textAlign: 'center',
    marginTop: '80%',
    color: 'black',
  },
 
});
