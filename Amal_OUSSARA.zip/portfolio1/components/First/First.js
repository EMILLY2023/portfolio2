import React from 'react';
import { StyleSheet, View, Text, Image, TouchableOpacity, Alert } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import * as ImagePicker from 'expo-image-picker';

export default function First(props) {

  const [image, setImage] = React.useState(null);

  // Demander l'autorisation d'accéder à la galerie
  React.useEffect(() => {
    (async () => {
      const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
      if (status !== 'granted') {
        Alert.alert('Permission refusée', 'L\'application a besoin d\'accéder à vos photos pour fonctionner.', [{text: 'OK'}], {cancelable: true});
      }
    })();
  }, []);

  // Fonction pour ouvrir la galerie et choisir une image
  const pickImage = async () => {
    let result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsEditing: true,
      aspect: [4, 3],
      quality: 1,
    });

    if (!result.cancelled) {
      setImage(result.uri);
    }
  };

 return (
<View style={styles.container}>
<Text style={styles.avatarText}>Amal OUSSARA</Text>
<TouchableOpacity onPress={pickImage}>
{image ? (
<Image source={{ uri: image }} style={styles.avatar} />
) : (
<Ionicons name="camera" size={80} color="grey" />
)}
</TouchableOpacity>
<Text style={styles.name}>{props.name}</Text>
<Text style={styles.job}>{props.job}</Text>
<View style={styles.socialLinks}>
<TouchableOpacity onPress={() => Linking.openURL('https://www.linkedin.com/in/amal-lahdari-198651261/')}>
<Ionicons name="logo-linkedin" size={30} color="blue" />
</TouchableOpacity>
<TouchableOpacity onPress={() => Linking.openURL('https://github.com/amaloussara')}>
<Ionicons name="logo-github" size={30} color="black" />
</TouchableOpacity>
<TouchableOpacity onPress={() => Linking.openURL('mailto:amallahdari@gmail.com')}>
<Ionicons name="mail" size={30} color="red" />
</TouchableOpacity>
</View>
<View style={styles.contactLinks}>
<TouchableOpacity onPress={() => Linking.openURL('tel:0606060606')}>
<Ionicons name="call" size={30} color="green" />
</TouchableOpacity>
<TouchableOpacity onPress={() => Linking.openURL('mailto:amallahdari@gmail.com')}>
<Ionicons name="mail" size={30} color="red" />
</TouchableOpacity>
<TouchableOpacity onPress={() => Linking.openURL('https://wa.me/0606060606')}>
<Ionicons name="chatbubbles" size={30} color="purple" />
</TouchableOpacity>
</View>
</View>
);
}

const styles = StyleSheet.create({
container: {
flex: 1,
alignItems: 'center',
justifyContent: 'center',
backgroundColor: '#f9c2ff',
},
avatarText: {
fontSize: 30,
fontWeight: 'bold',
fontStyle: 'italic',
color: ' #333333',
fontFamily: 'Arial Rounded MT Bold',
marginBottom: 10,
  },
  avatar: {
    width: 150,
    height: 150,
    borderRadius: 75,
    marginBottom: 20,
  },
  name: {
    fontSize: 30,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  job: {
    fontSize: 20,
    fontStyle: 'italic',
    marginBottom: 20,
  },
  socialLinks: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    alignItems: 'center',
    width: '100%',
    marginBottom: 20,
  },
  contactLinks: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    alignItems: 'center',
    width: '100%',
  },
});
