import * as React from 'react';
import { StyleSheet, View, Text, Image } from 'react-native';

export default function Home() {
  return (
    <View style={styles.container}>
    <Image source={require('./assets/hello.png')} style={styles.hello} />
      <View style={styles.titleContainer}>
        <Text style={styles.title}>Bienvenue sur notre application !</Text>
      </View>
      <Text style={styles.subtitle}>Découvrez notre contenu exclusif</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f9c2ff',
    justifyContent: 'center',
    alignItems: 'center',
  },
   hello: {
    width: 300, 
    height:150, 
    marginBottom: 10, 
  },
  titleContainer: {
    backgroundColor: '#FF1493', 
    paddingVertical: 10,
    paddingHorizontal: 20,
    borderRadius: 5,
  },
  title: {
    fontSize: 32,
    fontWeight: 'bold',
    color: '#fff', 
    textAlign: 'center',
  },
  subtitle: {
    fontSize: 24,
    color: '#333',
    textAlign: 'center',
    marginTop: 20,
  },
   
 
});
