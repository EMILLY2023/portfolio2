import *as React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import ThirdOne from './ThirdOne';
import ThirdSecond from './ThirdSecond';
import ThirdThird from './ThirdThird';


const Third = () => {
  return (
    <View style={styles.container}>
      <View style={{ flex: .5}}><ThirdOne /></View>
      <View style={{ flex: 2 }}>
        <ThirdSecond/>
      </View>
      <View style={{ flex: 1.5}}><ThirdThird/></View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flexDirection: 'column',
    flex: 1,

 

  }
  
});

export default Third;

