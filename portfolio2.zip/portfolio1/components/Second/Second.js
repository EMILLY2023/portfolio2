import React from 'react';
import { StyleSheet, Text, View, FlatList } from 'react-native';

const DATA = [
  { 
    "name": "Acme Corp",        
    "annee": 2020,        
    "poste": "Ingénieur logiciel",        
    "description": "Conception et développement de logiciels de gestion de projet."    
  },    
  {        
    "name": "XYZ Company",        
    "annee": 2019,        
    "poste": "Analyste financier",        
    "description": "Analyse des performances financières de l'entreprise et recommandations pour l'amélioration des résultats."    
  },    
  {        
    "name": "ABC Inc",        
    "annee": 2021,        
    "poste": "Chef de projet",        
    "description": "Coordination des équipes de développement pour la réalisation de projets informatiques."    
  },    
  {        
    "name": "DEF SA",        
    "annee": 2018,        
    "poste": "Responsable des ventes",        
    "description": "Gestion de l'équipe de vente et développement de la stratégie commerciale."    
  },    
  {        
    "name": "GHI Ltd",        
    "annee": 2022,        
    "poste": "Ingénieur réseau",        
    "description": "Gestion de l'infrastructure réseau de l'entreprise et maintenance des équipements."    
  },    
  {        
    "name": "JKL Corp",        
    "annee": 2020,        
    "poste": "Développeur web",        
    "description": "Création et maintenance de sites web pour les clients de l'entreprise."    
  },    
  {        
    "name": "MNO SA",        
    "annee": 2021,        
    "poste": "Responsable marketing",        
    "description": "Développement de la stratégie marketing de l'entreprise et gestion de l'équipe marketing."    
  },    
  {        
    "name": "PQR Inc",        
    "annee": 2019,        
    "poste": "Analyste de données",        
    "description": "Analyse des données de l'entreprise pour aider à la prise de décisions."    
  },    
  {        
    "name": "STU Ltd",        
    "annee": 2018,       
    "poste": "Chef de produit",        
    "description": "Développement de nouveaux produits et gestion du cycle de vie des produits existants."    
  },    
  {        
    "name": "VWX SA",        
    "annee": 2022,        
    "poste": "Ingénieur de test",        
    "description": "Conception et exécution de tests pour assurer la qualité des produits de l'entreprise."    
  }
]


const ExperienceItem = ({ name, annee, poste, description }) => {
  return (
    <View style={styles.item}>
      <Text style={styles.name}>{name}</Text>
      <Text style={styles.annee}>{annee}</Text>
      <Text style={styles.poste}>{poste}</Text>
      <Text style={styles.description}>{description}</Text>
    </View>
  );
};

const renderExperienceItem = ({ item }) => (
  <ExperienceItem name={item.name} annee={item.annee}  poste={item.poste} description={item.description} />
);

const Second= () => {
  return (
    <View style={styles.container}>
      <Text style={styles.header}>Expérience professionnelle</Text>
      <FlatList
        data={DATA}
        renderItem={renderExperienceItem}
        keyExtractor={(item) => item.annee}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    paddingHorizontal: 20,
    paddingTop: 50,
  },
  header: {
    fontSize: 32,
    fontWeight: 'bold',
    marginBottom: 20,
    justifyContent: 'center',
  },
  item: {
    backgroundColor: '#f9c2ff',
    padding: 20,
    marginBottom: 10,
  },
  name: {
    fontSize: 20,
    fontWeight: 'bold',
    
  },
  poste: {
     fontSize: 20,
    textDecorationLine: 'underline',
  },
  annee: {
    fontSize: 16,
    fontStyle: 'italic',
  },
  description: {
    fontSize: 16,
  },
});

export default Second;
